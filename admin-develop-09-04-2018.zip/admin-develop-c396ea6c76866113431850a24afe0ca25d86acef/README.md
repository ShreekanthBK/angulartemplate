# WiproMentorship

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.6.8.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `-prod` flag for a production build.

## Running lint

Run `ng lint` to execute lint.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).

## Sub Admin dashboard URL

http://localhost:4200/admin/dashboard/sub-admin


For Development:

This needs to be combine after integration with Login.
1. Connection area is unique to the sub Admin
```
<!-- new connections -->
<div class="clearfix connections">
  <h5>New Connections</h5>
  <div class="cards clearfix">
    <div class="card panel" *ngFor="let connection of dashboard.connections;">
      <app-sub-admin-connection [data]="connection"></app-sub-admin-connection>
    </div>
  </div>
  <a routerLink="/admin/connections" class="btn-green">View All Connections</a>
</div>

```
2. Dashboard Status at the to also having minor difference
3. NEW LEARNING AREA REQUESTS widget is not available in sub admin dashboard
