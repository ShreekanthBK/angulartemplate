import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';

import 'rxjs/add/operator/share';
import { Observable } from 'rxjs/Observable';


import {environment} from '../../environments/environment';

@Injectable()
export class DataService {

  constructor(private http: HttpClient) {
  }


  /**
   * Loading data from JSON files
   * @param name
   * @returns {any}
   */
  getData(name) {
    return this.http.get(environment.api.replace('{name}', name)).share().toPromise();
  }
  get(urlAddress: string): Observable<string[]> {
    return this.http.get<string[]>(urlAddress);
  }

}


