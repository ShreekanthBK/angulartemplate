import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {DashboardComponent} from '../../pages/dashboard/dashboard.component';
import {LearningAreasComponent} from '../../pages/learning-areas/learning-areas.component';
import {CreateLearningAreaComponent} from '../../pages/create-learning-area/create-learning-area.component';
import {LearningAreaConfigComponent} from '../../pages/learning-area-config/learning-area-config.component';
import {MentorsComponent} from '../../pages/mentors/mentors.component';
import {SubAdminComponent} from '../../pages/sub-admin/sub-admin.component';
import {ConnectionsComponent} from '../../pages/connections/connections.component';
import {SubAdminDashboardComponent} from '../../pages/sub-admin-dashboard/sub-admin-dashboard.component';
import {AdminComponent} from '../../pages/admin/admin.component';
import {LoginComponent} from '../../pages/login/login.component';
import {MentorProfileEditComponent} from '../../pages/mentor-profile-edit/mentor-profile-edit.component';
import {OtherProfileMentorComponent} from '../../pages/other-profile-mentor/other-profile-mentor.component';
import {OtherProfileMenteeComponent} from '../../pages/other-profile-mentee/other-profile-mentee.component';

const routes: Routes = [
  {
    path: 'admin', component: AdminComponent, children: [
      {path: 'dashboard', component: DashboardComponent},
      {path: 'dashboard/sub-admin', component: SubAdminDashboardComponent},
      {path: 'mentors', component: MentorsComponent},
      {path: 'sub-admin', component: SubAdminComponent},
      {path: 'connections', component: ConnectionsComponent},
      {path: 'learning-areas', component: LearningAreasComponent},
      {path: 'learning-areas/config', component: LearningAreaConfigComponent},
      {path: 'learning-areas/create', component: CreateLearningAreaComponent},
      {path: 'other-profile-mentor', component: OtherProfileMentorComponent},
      {path: 'other-profile-mentee', component: OtherProfileMenteeComponent},
      {path: 'profile-edit', component: MentorProfileEditComponent},
      {path: '**', redirectTo: '/admin/dashboard'},
    ]
  },
  {path: 'login', component: LoginComponent},
  {path: '**', redirectTo: '/admin/dashboard'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class RoutesModule {
}
