import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { RoutesModule } from './routes/routes/routes.module';
import { NgxCarouselModule } from 'ngx-carousel';
import { NgxPaginationModule } from 'ngx-pagination';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

import 'hammerjs';

import { AppComponent } from './app.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { HeaderComponent } from './components/header/header.component';
import { SideMenuComponent } from './components/side-menu/side-menu.component';
import { DataService } from './services/data.service';
import { DashboardStatusCardComponent } from './components/dashboard-status-card/dashboard-status-card.component';
import { DashboardMentorComponent } from './components/dashboard-mentor/dashboard-mentor.component';
import { LearningRequestComponent } from './components/learning-request/learning-request.component';
import { MoreComponent } from './components/more/more.component';
import { DropdownComponent } from './components/dropdown/dropdown.component';
import { LearningAreaComponent } from './components/learning-area/learning-area.component';
import { AccountListComponent } from './components/account-list/account-list.component';
import { LearningAreasComponent } from './pages/learning-areas/learning-areas.component';
import { LearningCardComponent } from './components/learning-card/learning-card.component';
import { LearningTableRowComponent } from './components/learning-table-row/learning-table-row.component';
import { DashboardMentorCardComponent } from './components/dashboard-mentor-card/dashboard-mentor-card.component';
import { ShareDocumentModalComponent } from './components/share-document-modal/share-document-modal.component';
import { FileDropZoneComponent } from './components/file-drop-zone/file-drop-zone.component';
import { BulkUploadComponent } from './components/bulk-upload/bulk-upload.component';
import { CreateLearningAreaComponent } from './pages/create-learning-area/create-learning-area.component';
import { PreviewComponent } from './components/preview/preview.component';
import { MentorSelectComponent } from './components/mentor-select/mentor-select.component';
import { SearchPipe } from './pipes/search.pipe';
import { OrderByPipe } from './pipes/order-by.pipe';
import { LearningAreaConfigComponent } from './pages/learning-area-config/learning-area-config.component';
import { MentorListComponent } from './components/mentor-list/mentor-list.component';
import { InviteModalComponent } from './components/invite-modal/invite-modal.component';
import { MentorsComponent } from './pages/mentors/mentors.component';
import { LeaderBoardComponent } from './components/leader-board/leader-board.component';
import { MentorTableComponent } from './components/mentor-table/mentor-table.component';
import { MentorModalComponent } from './components/mentor-modal/mentor-modal.component';
import { SubAdminComponent } from './pages/sub-admin/sub-admin.component';
import { SubAdminCardComponent } from './components/sub-admin-card/sub-admin-card.component';
import { SubAdminActivityComponent } from './components/sub-admin-activity/sub-admin-activity.component';
import { SubAdminAssignModalComponent } from './components/sub-admin-assign-modal/sub-admin-assign-modal.component';
import { ConnectionsComponent } from './pages/connections/connections.component';
import { ConnectionTableComponent } from './components/connection-table/connection-table.component';
import { ConnectionLimitModalComponent } from './components/connection-limit-modal/connection-limit-modal.component';
import { SubAdminDashboardComponent } from './pages/sub-admin-dashboard/sub-admin-dashboard.component';
import { SubAdminConnectionComponent } from './components/sub-admin-connection/sub-admin-connection.component';
import { SearchallPipe } from './pipes/searchall.pipe';
import { MessageModalComponent } from './components/message-modal/message-modal.component';
import { ConfirmationModalComponent } from './components/confirmation-modal/confirmation-modal.component';
import { AdminComponent } from './pages/admin/admin.component';
import { OtherProfileMenteeComponent } from './pages/other-profile-mentee/other-profile-mentee.component';
import { OtherProfileMentorComponent } from './pages/other-profile-mentor/other-profile-mentor.component';
import { LoginComponent } from './pages/login/login.component';
import { ReviewPanelComponent } from './components/review-panel/review-panel.component';
import { ProfileEditComponent } from './components/profile-edit/profile-edit.component';
import { MentorProfileEditComponent } from './pages/mentor-profile-edit/mentor-profile-edit.component';
import { ProfileReadonlyComponent } from './components/profile-readonly/profile-readonly.component';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    HeaderComponent,
    SideMenuComponent,
    DashboardStatusCardComponent,
    DashboardMentorComponent,
    LearningRequestComponent,
    MoreComponent,
    DropdownComponent,
    LearningAreaComponent,
    AccountListComponent,
    LearningAreasComponent,
    LearningCardComponent,
    LearningTableRowComponent,
    DashboardMentorCardComponent,
    ShareDocumentModalComponent,
    FileDropZoneComponent,
    BulkUploadComponent,
    CreateLearningAreaComponent,
    PreviewComponent,
    MentorSelectComponent,
    SearchPipe,
    SearchallPipe,
    OrderByPipe,
    LearningAreaConfigComponent,
    MentorListComponent,
    InviteModalComponent,
    MentorsComponent,
    LeaderBoardComponent,
    MentorTableComponent,
    MentorModalComponent,
    SubAdminComponent,
    SubAdminCardComponent,
    SubAdminActivityComponent,
    SubAdminAssignModalComponent,
    ConnectionsComponent,
    ConnectionTableComponent,
    ConnectionLimitModalComponent,
    SubAdminDashboardComponent,
    SubAdminConnectionComponent,
    MessageModalComponent,
    ConfirmationModalComponent,
    AdminComponent,
    OtherProfileMenteeComponent,
    OtherProfileMentorComponent,
    LoginComponent,
    ReviewPanelComponent,
    ProfileEditComponent,
    MentorProfileEditComponent,
    ProfileReadonlyComponent,
  ],
  imports: [
    HttpClientModule,
    RoutesModule,
    FormsModule,
    BrowserModule,
    NgxCarouselModule,
    NgxPaginationModule,
    NgbModule.forRoot()
  ],
  providers: [
    DataService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
