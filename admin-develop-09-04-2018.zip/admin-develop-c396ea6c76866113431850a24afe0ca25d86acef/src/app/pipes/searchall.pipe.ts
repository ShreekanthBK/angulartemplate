import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
  name: 'searchall'
})
export class SearchallPipe implements PipeTransform {

  transform(items: any, args: string): any {
    if (!args) {
      return items;
    } else {
      return items
        .filter(item => {
          delete item['id'];
          return Object.values(item).join(' ').toLowerCase().indexOf(args.toLowerCase()) > -1;
        });
    }
  }
}
