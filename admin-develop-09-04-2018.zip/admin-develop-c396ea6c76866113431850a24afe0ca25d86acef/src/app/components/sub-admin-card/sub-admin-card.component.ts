import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-sub-admin-card',
  templateUrl: './sub-admin-card.component.html',
  styleUrls: ['./sub-admin-card.component.scss']
})
export class SubAdminCardComponent implements OnInit {

  @Output() remove: EventEmitter<any> = new EventEmitter;
  @Input() item = {
    status: '',
    image: '',
    name: '',
    designation: ''
  };
  @Input() index = 0;

  constructor() {
  }

  ngOnInit() {
  }

  /**
   * On remove event
   * @param index
   */
  onRemove(index) {
    this.remove.emit(index);
  }
}
