import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-connection-limit-modal',
  templateUrl: './connection-limit-modal.component.html',
  styleUrls: ['./connection-limit-modal.component.scss']
})
export class ConnectionLimitModalComponent implements OnInit {


  @Output() set: EventEmitter<any> = new EventEmitter;
  @Output() cancel: EventEmitter<any> = new EventEmitter;
  @Input() mentorDropDown = [];
  @Input() menteeDropDown = [];
  mentor = '5';
  mentee = '5';
  constructor() {
  }

  ngOnInit() {
  }

  /**
   * set event
   */
  onSet() {
    this.set.emit();
  }

  /**
   * cancel event
   */
  onCancel() {
    this.cancel.emit();
  }

  /**
   * Drop down update
   * @param value - updated value
   * @param field - field name
   */
  onDropdownChange(value, field) {
    this[field] = value;
  }


}
