import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-dashboard-mentor-card',
  templateUrl: './dashboard-mentor-card.component.html',
  styleUrls: ['./dashboard-mentor-card.component.scss']
})
export class DashboardMentorCardComponent implements OnInit {

  @Output() approve: EventEmitter<any> = new EventEmitter;
  @Output() reject: EventEmitter<any> = new EventEmitter;
  @Input() data: any = {};

  constructor() {
  }

  ngOnInit() {
  }

  /**
   * Aprpove Action
   */
  onApprove() {
    this.approve.emit();
  }

  /**
   * Reject Action
   */
  onReject() {
    this.reject.emit();
  }

}
