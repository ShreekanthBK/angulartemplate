import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-profile-readonly',
  templateUrl: './profile-readonly.component.html',
  styleUrls: ['./profile-readonly.component.scss']
})
export class ProfileReadonlyComponent implements OnInit {

  @Input() dataList: any[];
  @Input() pageType = '';
  @Input() userRole = '';

  /**
   * Creates an instance of the ProfileReadonlyComponent
   */
  constructor(private router: Router) {}

  /**
   * Get the dataList OnInit
   */
  ngOnInit() {
  }

  // click Edit Profile
  clickEditProfile() {
    if (this.userRole === 'mentee') {
      this.router.navigate(['/mentee/mentee-profile-edit']);
    } else if (this.userRole === 'mentor') {
      this.router.navigate(['/mentor/mentor-profile-edit']);
    }
  }
}
