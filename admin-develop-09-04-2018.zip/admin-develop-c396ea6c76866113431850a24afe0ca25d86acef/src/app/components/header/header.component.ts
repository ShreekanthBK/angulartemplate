import {Component, EventEmitter, ViewChild, HostListener, Input, OnInit, Output, OnDestroy} from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import {DataService} from '../../services/data.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit, OnDestroy {

  user: any = {};
  @Input() open = false;
  openDropDown = false;
  @Output() toggleMenu: EventEmitter<any> = new EventEmitter;

  hiddenElementGroup = {
    showMenu: false,
    showSearchPopup: false,
    showSearchPopupMobile: false,
    showNotification: false
  };
  @Input() activeMenu = '';
  @Input() status = '';

  errorMessage: string;
  dataList: any = [];

  notificationList = [];

  searchKeyword = '';
  searchLearningAreasList: any[] = [];
  searchEmployeesList: any[] = [];

  @ViewChild('connectSentModal') connectSentModal: any;
  connectSentModalRef: NgbModalRef;

  constructor(private dataService: DataService, private modalService: NgbModal) {
  }

  ngOnInit() {
    const href = window.location.href;
    this.dataService.getData(href.indexOf('/dashboard/sub-admin') !== -1 ? 'user-sub-admin' : 'user').then((data: any) => this.user = data);
    this.dataService.getData('dataHeader').then(dataList => this.dataList = dataList).then(() => this.initData());
  }

  /**
   * Document click
   * @param event
   */
  @HostListener('document:click', ['$event'])
  hideDropDown(event) {
    this.openDropDown = false;
  }

  /**
   * Menu click
   */
  clickMenu() {
    this.toggleMenu.emit();
  }

  /**
   * Get the dataList OnInit
   */

  initData() {
    this.notificationList = this.dataList['notificationList'];
  }

  /**
   * OnDestroy
   */
  ngOnDestroy() {
    if (this.connectSentModalRef !== undefined) {
      this.connectSentModalRef.close();
    }
  }

  // openModalWindow
  openModalWindow(modalId) {
    const modalRef = this.modalService.open(modalId);
    modalRef.result.then((result) => {
    }, (reason) => {
    });
    return modalRef;
  }

  // type on search input
  onKeySearch(event: any, deviceType) {
    const searchLearningAreasList_Temp = [];
    const searchEmployeesList_Temp = [];
    this.searchLearningAreasList = [];
    this.searchEmployeesList = [];

    const searchLabel = event.target.value;
    if (searchLabel.trim() !== '') {
      this.dataList['searchList']['learningAreas'].forEach(function(item, index) {
        if (item['title'].toLowerCase().indexOf(searchLabel.toLowerCase()) > -1) {
          const item_index = item['title'].toLowerCase().indexOf(searchLabel.toLowerCase());

          const firstLabel = item['title'].slice(0, item_index);
          const middleLabel = item['title'].slice(item_index, searchLabel.length + item_index);
          const lastLabel = item['title'].slice(searchLabel.length + item_index);

          searchLearningAreasList_Temp.push({
            'firstLabel': firstLabel,
            'middleLabel': middleLabel,
            'lastLabel': lastLabel,
            item
          });
        }
      });

      this.dataList['searchList']['employees'].forEach(function(item, index) {
        if (item['title'].toLowerCase().indexOf(searchLabel.toLowerCase()) > -1) {
          const item_index = item['title'].toLowerCase().indexOf(searchLabel.toLowerCase());

          const firstLabel = item['title'].slice(0, item_index);
          const middleLabel = item['title'].slice(item_index, searchLabel.length + item_index);
          const lastLabel = item['title'].slice(searchLabel.length + item_index);

          searchEmployeesList_Temp.push({
            'firstLabel': firstLabel,
            'middleLabel': middleLabel,
            'lastLabel': lastLabel,
            item
          });
        }
      });

      this.searchLearningAreasList = searchLearningAreasList_Temp;
      this.searchEmployeesList = searchEmployeesList_Temp;

      if (this.searchLearningAreasList.length > 0
        || this.searchEmployeesList.length > 0) {
        if (deviceType === 'desktop') {
          this.hiddenElementGroup['showSearchPopup'] = true;
        }
      }
    }
  }

}
