import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'app-sub-admin-activity',
  templateUrl: './sub-admin-activity.component.html',
  styleUrls: ['./sub-admin-activity.component.scss']
})
export class SubAdminActivityComponent implements OnInit {

  @Input() items = [];
  @Input() title = '';

  constructor() { }

  ngOnInit() {
  }

}
