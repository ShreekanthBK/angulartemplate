import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'app-mentor-list',
  templateUrl: './mentor-list.component.html',
  styleUrls: ['./mentor-list.component.scss']
})
export class MentorListComponent implements OnInit {

  @Input() items: any = [];

  constructor() {
  }

  ngOnInit() {
  }

}
