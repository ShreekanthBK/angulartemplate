import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-connection-table',
  templateUrl: './connection-table.component.html',
  styleUrls: ['./connection-table.component.scss']
})
export class ConnectionTableComponent implements OnInit {


  @Output() close: EventEmitter<any> = new EventEmitter;
  @Input() items: any = [];
  @Input() filterStatus: any = '';
  @Input() category: any = '';
  @Input() subCategory: any = '';
  orderBy: any = '';
  orderDirection: any = true;

  constructor() {
  }

  ngOnInit() {
  }

  /**
   * Sort table
   * @param name - field name
   */
  sort(name) {
    if (this.orderBy === name) {
      this.orderDirection = !this.orderDirection;
    } else {
      this.orderBy = name;
      this.orderDirection = true;
    }
  }

  /**
   * Close action
   * @param index - index
   */
  onClose(index) {
    this.close.emit(index);
  }

}
