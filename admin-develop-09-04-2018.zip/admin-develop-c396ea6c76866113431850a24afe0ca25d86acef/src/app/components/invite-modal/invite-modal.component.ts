import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-invite-modal',
  templateUrl: './invite-modal.component.html',
  styleUrls: ['./invite-modal.component.scss']
})
export class InviteModalComponent implements OnInit {

  @Output() invite: EventEmitter<any> = new EventEmitter;
  @Output() cancel: EventEmitter<any> = new EventEmitter;
  @Input() title = '';
  @Input() users = [];
  @Input() mentees = [];
  selectedUsers = [];
  selectedMentees = [];
  _query = '';
  query = '';
  _menteeQuery = '';
  menteeQuery = '';
  tab = 'INVITE_EMPLOYEE';
  mentorFile = null;
  menteeFile = null;

  constructor() {
  }

  ngOnInit() {
    for (let i = 0; i < this.users.length; i++) {
      this.users[i].added = false;
    }
  }

  /**
   * cancel modal
   */
  onCancel() {
    this.cancel.emit();
  }


  /**
   * Invite Mentors/Employees
   */
  onInvite() {
    this.invite.emit();
  }

  /**
   * Add employee
   * @param index - index
   * @param added - added flag
   * @returns {boolean}
   */
  addEmployee(index, added) {
    if (added) {
      return false;
    }
    for (let i = 0; i < this.users.length; i++) {
      if (this.users[i].id === index) {
        this.users[i].added = true;
        this.selectedUsers.push({...this.users[i]});
      }
    }
  }

  /**
   * Add mentee
   * @param index - index
   * @param added - added flag
   * @returns {boolean}
   */
  addMentee(index, added) {
    if (added) {
      return false;
    }
    for (let i = 0; i < this.mentees.length; i++) {
      if (this.mentees[i].id === index) {
        this.mentees[i].added = true;
        this.selectedMentees.push({...this.mentees[i]});
      }
    }
  }

  /**
   * Remove employee
   * @param id - id
   * @param index - looping index
   */
  removeEmployee(id, index) {
    this.selectedUsers.splice(index, 1);
    for (let i = 0; i < this.users.length; i++) {
      if (this.users[i].id === id) {
        this.users[i].added = false;
      }
    }
  }

  /**
   * Remove mentee
   * @param id - id
   * @param index - looping index
   */
  removeMentee(id, index) {
    this.selectedMentees.splice(index, 1);
    for (let i = 0; i < this.mentees.length; i++) {
      if (this.mentees[i].id === id) {
        this.mentees[i].added = false;
      }
    }
  }

  /**
   * Search employee
   */
  onSearch() {
    this.query = this._query;
  }

  /**
   * Search mentee
   */
  onSearchMentee() {
    this.menteeQuery = this._menteeQuery;
  }

  /**
   * Clear employee list
   */
  clearEmployeeList() {
    while (this.selectedUsers.length !== 0) {
      this.removeEmployee(this.selectedUsers[0].id, 0);
    }
  }

  /**
   * Clear metee list
   */
  clearMenteeList() {
    while (this.selectedMentees.length !== 0) {
      this.removeMentee(this.selectedMentees[0].id, 0);
    }
  }

  /**
   * Upload file
   * @param file - file name
   * @param field - field name
   */
  uploadMentorFile(file, field) {
    this[field] = file;
  }

  /**
   * Get invite button disabled status
   */
  getDisabledStatus() {
    if (this.tab === 'UPLOAD_LIST' && (this.menteeFile === null || this.mentorFile == null)) {
      return true;
    } else if (this.tab === 'INVITE_MENTEE' && (this.selectedMentees.length === 0)) {
      return true;
    } else if (this.tab === 'INVITE_EMPLOYEE' && (this.selectedUsers.length === 0)) {
      return true;
    }
    return false;
  }
}
