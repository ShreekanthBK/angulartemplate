import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-mentor-modal',
  templateUrl: './mentor-modal.component.html',
  styleUrls: ['./mentor-modal.component.scss']
})
export class MentorModalComponent implements OnInit {

  @Output() update: EventEmitter<any> = new EventEmitter;
  @Output() cancel: EventEmitter<any> = new EventEmitter;
  @Input() learningDropDown = {};
  @Input() categoryDropDown = [];
  @Input() items = [];
  @Input() title = '';
  @Input() uploadText = '';
  @Input() dropdowns = true;
  @Input() actionText = '';

  @Input() dropText = '';

  tabIndex = 0;
  selectAll = false;
  fileSelected = null;
  category = 'Category';
  areas = 'Learning Areas';
  _query = '';
  query = '';

  constructor() {
  }

  ngOnInit() {
    for (let i = 0; i < this.items.length; i++) {
      this.items[i].checked = false;
    }
  }

  getSelectedCount() {
    let count = 0;
    for (let i = 0; i < this.items.length; i++) {
      if (this.items[i].checked) {
        count++;
      }
    }
    return count;
  }

  /**
   * Change search query
   */
  onChange() {
    this.selectAll = false;
    if (this.getSelectedCount() === this.items.length) {
      this.selectAll = true;
    }
  }

  /**
   * Update event
   */
  onUpdate() {
    this.update.emit();
  }

  /**
   * cancel event
   */
  onCancel() {
    this.cancel.emit();
  }

  /**
   * Upload file
   * @param file - file info
   */
  uploadFile(file) {
    this.fileSelected = file;
  }

  /**
   * On category change
   * @param value
   */
  onCategoryChange(value) {
    if (this.category !== value) {
      this.areas = 'Learning Areas';
    }
    this.category = value;
  }

  /**
   * On area change
   * @param value
   */
  onAreasChange(value) {
    this.areas = value;
  }

  /**
   * toggle select and deselect
   */
  selectToggle() {
    if (this.selectAll) {
      for (let i = 0; i < this.items.length; i++) {
        this.items[i].checked = false;
      }
    } else {

      for (let i = 0; i < this.items.length; i++) {
        if (this.query === undefined || this.items[i].name.toLowerCase().indexOf(this.query.toLowerCase()) !== -1) {
          this.items[i].checked = true;
        }
      }
    }
    this.selectAll = !this.selectAll;
  }

  /**
   * Search employee
   */
  onSearch() {
    this.query = this._query;
  }

  getEnabledStatus() {
    if (this.category === 'Category' || this.areas === 'Learning Areas') {
      return true;
    }
    if (this.tabIndex === 0 && this.getSelectedCount() === 0) {
      return true;
    } else if (this.tabIndex === 1 && this.fileSelected === null) {
      return true;
    }
    return false;
  }
}
