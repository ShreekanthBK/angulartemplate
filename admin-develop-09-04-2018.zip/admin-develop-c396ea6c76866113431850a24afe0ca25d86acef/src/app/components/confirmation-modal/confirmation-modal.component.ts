import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-confirmation-modal',
  templateUrl: './confirmation-modal.component.html',
  styleUrls: ['./confirmation-modal.component.scss']
})
export class ConfirmationModalComponent implements OnInit {

  @Output() no: EventEmitter<any> = new EventEmitter;
  @Output() yes: EventEmitter<any> = new EventEmitter;
  @Input() title = '';
  @Input() message = '';
  @Input() value = null;
  @Input() type = null;
  @Input() dropdowns = false;

  constructor() {
  }

  ngOnInit() {
  }

  /**
   * Click on No button
   */
  onNo() {
    this.no.emit();
  }

  /**
   * Click on yes button
   */
  onYes() {
    this.yes.emit({ type: this.type, value: this.value});
  }
}
