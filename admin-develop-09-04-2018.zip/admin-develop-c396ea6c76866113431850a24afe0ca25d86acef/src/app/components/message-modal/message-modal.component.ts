import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-message-modal',
  templateUrl: './message-modal.component.html',
  styleUrls: ['./message-modal.component.scss']
})
export class MessageModalComponent implements OnInit {

  @Output() cancel: EventEmitter<any> = new EventEmitter;
  @Input() title = '';
  @Input() dropdowns = false;
  @Input() message = '';

  constructor() {
  }

  ngOnInit() {
  }

  /**
   * cancel event
   */
  onCancel() {
    this.cancel.emit();
  }

}
