import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-sub-admin-connection',
  templateUrl: './sub-admin-connection.component.html',
  styleUrls: ['./sub-admin-connection.component.scss']
})
export class SubAdminConnectionComponent implements OnInit {

  @Output() close: EventEmitter<any> = new EventEmitter;
  @Input() data = {
    index: '',
    mentor: '',
    mentorName: '',
    mentee: '',
    menteeName: '',
    status: '',
    date: ''
  };

  constructor() {
  }

  ngOnInit() {
  }

  /**
   * On Close event
   * @param index
   */
  onClose(index) {
    this.close.emit(index);
  }

}
