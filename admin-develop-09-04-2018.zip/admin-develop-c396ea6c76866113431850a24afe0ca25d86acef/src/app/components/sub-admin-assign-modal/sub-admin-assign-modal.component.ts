import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-sub-admin-assign-modal',
  templateUrl: './sub-admin-assign-modal.component.html',
  styleUrls: ['./sub-admin-assign-modal.component.scss']
})
export class SubAdminAssignModalComponent implements OnInit {

  @Input() title = '';
  @Input() businessLine = 'Choose';
  @Input() category = 'Choose';
  @Input() learningAreas = 'Choose';
  @Input() member = {
    image: '',
    name: '',
    title: '',
  };

  @Input() businessLineDropDown = [];
  @Input() categoryDropDown = [];
  @Input() learningAreasDropDown = [];

  @Output() assign: EventEmitter<any> = new EventEmitter;
  @Output() cancel: EventEmitter<any> = new EventEmitter;

  selectMember = false;

  constructor() {
  }

  ngOnInit() {
  }

  /**
   * cancel event
   */
  onCancel() {
    this.cancel.emit();
  }

  /**
   * assign event
   */
  onAssign() {
    this.assign.emit();
  }

  /**
   * Drop down update
   * @param value - updated value
   * @param field - field name
   */
  onDropdownChange(value, field) {
    this[field] = value;
  }

  /**
   * Enable assign button
   * @returns {boolean}
   */
  enableAssign() {
    return this.businessLine === 'Choose' || this.category === 'Choose' || this.learningAreas === 'Choose' || this.selectMember === false;
  }
}
