import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-mentor-table',
  templateUrl: './mentor-table.component.html',
  styleUrls: ['./mentor-table.component.scss']
})
export class MentorTableComponent implements OnInit {


  @Output() remove: EventEmitter<any> = new EventEmitter;
  @Output() reject: EventEmitter<any> = new EventEmitter;
  @Output() approve: EventEmitter<any> = new EventEmitter;
  @Output() cancel: EventEmitter<any> = new EventEmitter;
  @Output() resend: EventEmitter<any> = new EventEmitter;

  @Input() items = [];
  @Input() title = '';
  @Input() pageSizes = [];
  @Input() id = '';
  @Input() type = '';
  currentPage = 1;
  itemsPerPage = 10;
  filter = '';
  orderBy = '';
  orderDirection = true;

  constructor() {
  }

  /**
   * Approve
   */
  onApprove(index) {
    this.approve.emit({type: 'APPROVE', value: index});
  }

  /**
   * Reject
   */
  onReject(index) {
    this.reject.emit({type: 'REJECT', value: index});
  }

  /**
   * Approve
   */
  onRemove(index) {
    this.remove.emit({type: 'REMOVE', value: index});
  }

  /**
   * Cancel
   */
  onCancel(index) {
    this.cancel.emit({type: 'CANCEL', value: index});
  }

  /**
   * Resend
   */
  onResend(index) {
    this.resend.emit({type: 'RESEND', value: index});
  }

  ngOnInit() {
  }

  /**
   * On page size change
   * @param value
   */
  onPageSize(value) {
    this.itemsPerPage = parseInt(value, 10);
  }

  /**
   * On current page change
   * @param value
   */
  onChangePage(value) {
    this.currentPage = parseInt(value, 10);
  }

  /**
   * Get Number of pages
   * @param length - total records
   * @returns {Array}
   */
  getNoOfPages(length) {
    const options = [];
    const noOfpages = Math.ceil(length / this.itemsPerPage);
    for (let i = 1; i <= noOfpages; i++) {
      options.push({name: i});
    }
    return options;
  }

  /**
   * got to last page
   */
  goToLast() {
    this.currentPage = Math.ceil(this.items.length / this.itemsPerPage);
  }

  /**
   * Sort table
   * @param name - field name
   */
  sort(name) {
    if (this.orderBy === name) {
      this.orderDirection = !this.orderDirection;
    } else {
      this.orderBy = name;
      this.orderDirection = true;
    }
  }
}
