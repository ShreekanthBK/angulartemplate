import { Component, HostListener, OnInit, Input, OnDestroy, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';

import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-profile-edit',
  templateUrl: './profile-edit.component.html',
  styleUrls: ['./profile-edit.component.scss']
})
export class ProfileEditComponent implements OnInit, OnDestroy {
  @Input() dataList: any[];
  @Input() modelPeriodFrom: NgbDateStruct;
  @Input() modelPeriodTo: NgbDateStruct;
  @Input() userRole = '';

  domainDropDown = [
    { name: 'All'},
    { name: 'Information Technology'},
    { name: 'Option 1'},
    { name: 'Option 2'},
    { name: 'Option 3'}
  ];
  GeneralAreaDropDown = [
    { name: 'All'},
    { name: 'Career Development'},
    { name: 'Option 1'},
    { name: 'Option 2'},
    { name: 'Option 3'}
  ];
  learningAreaDropDown = [
    { name: 'All'},
    { name: 'Learning Javascript'},
    { name: 'Option 1'},
    { name: 'Option 2'},
    { name: 'Option 3'}
  ];
  categoryDropDown = [
    { name: 'All'},
    { name: 'Programming'},
    { name: 'Option 1'},
    { name: 'Option 2'},
    { name: 'Option 3'}
  ];
  bandDropDown = [
    { name: 'All'},
    { name: 'B2'},
    { name: 'B4'},
    { name: 'B4'}
  ];

  modelPeriodFromStored: NgbDateStruct;
  modelPeriodToStored: NgbDateStruct;

  showError = false;
  showEmailError = false;

  @ViewChild('appSentModal') appSentModal: any;
  appSentModalRef: NgbModalRef;

  /**
   * Creates an instance of the ProfileEditComponent
   */
  constructor(private router: Router,
              private location: Location,
              private modalService: NgbModal) {}

  /**
   * Get the dataList OnInit
   */
  ngOnInit() {
    this.modelPeriodFromStored = { year: null, month: null, day: null };
    this.modelPeriodToStored = { year: null, month: null, day: null };
  }

  /**
   * OnDestroy
   */
  ngOnDestroy() {
    if (this.appSentModalRef !== undefined) {
      this.appSentModalRef.close();
    }
  }

  /**
   * Drop down update
   * @param value - updated value
   * @param field - field name
   */
  onDropdownChange(value, field) {
    if ( field === 'domain') {
      this.dataList[0]['Volunteer as Mentee']['learningCategory'] = value;
    } else if ( field === 'general') {
      this.dataList[0]['Volunteer as Mentee']['learningArea'] = value;
    } else if (field === 'learningArea2') {
      this.dataList[0]['Volunteer as Mentor']['learningCategory'] = value;
    } else if (field === 'band') {
      this.dataList[0]['Skills and Band']['band'] = value;
    }
  }

  // click Save button
  clickSave() {
    this.showError = true;

    if (this.dataList[0]['personalDetails']['Name'] !== ''
      && this.dataList[0]['personalDetails']['Email'] !== ''
      && this.dataList[0]['personalDetails']['Phone'] !== ''
      && this.dataList[0]['personalDetails']['Domain'] !== ''
      && this.dataList[0]['personalDetails']['Designation'] !== ''
      && this.dataList[0]['personalDetails']['Location'] !== ''
      && this.dataList[0]['personalDetails']['Wipro Experience'] !== ''
      && this.dataList[0]['personalDetails']['Total Experience'] !== ''
      && this.dataList[0]['aboutMyCurrentRole']['description'] !== ''
      && this.dataList[0]['aboutMyCurrentRole']['specialties'] !== ''
      && this.dataList[0]['aboutMyCurrentRole']['strengthAreas'] !== ''
      && this.dataList[0]['workDetails']['title'] !== ''
      && this.dataList[0]['workDetails']['description'] !== ''
      && this.dataList[0]['Volunteer as Mentee']['description'] !== ''
      && this.dataList[0]['Volunteer as Mentee']['keyStrengths'] !== ''
      && this.dataList[0]['Volunteer as Mentor']['description'] !== ''
      && this.dataList[0]['Volunteer as Mentor']['keyStrengths'] !== ''
      && this.modelPeriodFrom !== undefined
      && this.modelPeriodTo !== undefined) {
      const filter  = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
      if (filter.test(this.dataList[0]['personalDetails']['Email'])) {
        this.showEmailError = false;
        this.router.navigate(['/admin/dashboard']);
      } else {
        this.showEmailError = true;
      }
    }
  }

  // remove skill
  removeSkill(item, index) {
    item.splice(index, 1);
  }

  // add Skill
  addSkill(item) {
    item.push({
      'value': ''
    });
  }

  // click Cancel
  cancel() {
    this.location.back();
  }

  // change the date selection
  changeStartDate() {
    if (this.modelPeriodTo !== undefined) {
      if (this.modelPeriodTo !== null) {
        if (!this.compareNgbDateStruct(this.modelPeriodFrom, this.modelPeriodTo)) {
          this.modelPeriodFromStored = {year: this.modelPeriodFrom.year, month: this.modelPeriodFrom.month, day: this.modelPeriodFrom.day};
        } else {
          this.modelPeriodFrom = {
            year: this.modelPeriodFromStored.year,
            month: this.modelPeriodFromStored.month,
            day: this.modelPeriodFromStored.day
          };
        }
      } else {
        this.modelPeriodFromStored = {year: this.modelPeriodFrom.year, month: this.modelPeriodFrom.month, day: this.modelPeriodFrom.day};
      }
    } else {
      this.modelPeriodFromStored = {year: this.modelPeriodFrom.year, month: this.modelPeriodFrom.month, day: this.modelPeriodFrom.day};
    }
  }

  changeEndDate() {
    if (this.modelPeriodFrom !== undefined) {
      if (this.modelPeriodFrom !== null) {
        if (!this.compareNgbDateStruct(this.modelPeriodFrom, this.modelPeriodTo)) {
          this.modelPeriodToStored = {year: this.modelPeriodTo.year, month: this.modelPeriodTo.month, day: this.modelPeriodTo.day};
        } else {
          this.modelPeriodTo = {
            year: this.modelPeriodToStored.year,
            month: this.modelPeriodToStored.month,
            day: this.modelPeriodToStored.day
          };
        }
      } else {
        this.modelPeriodToStored = {year: this.modelPeriodTo.year, month: this.modelPeriodTo.month, day: this.modelPeriodTo.day};
      }
    } else {
      this.modelPeriodToStored = {year: this.modelPeriodTo.year, month: this.modelPeriodTo.month, day: this.modelPeriodTo.day};
    }
  }

  // compare the NgbDateStruct values
  compareNgbDateStruct(firstValue, secondValue) {
    if (firstValue === undefined || firstValue === null
      || secondValue === undefined || secondValue === null) {
      return true;
    }
    let bigger = false;
    if (firstValue.year > secondValue.year) {
      bigger = true;
    } else if (firstValue.year === secondValue.year) {
      if (firstValue.month > secondValue.month) {
        bigger = true;
      } else if (firstValue.month === secondValue.month) {
        if (firstValue.day > secondValue.day) {
          bigger = true;
        }
      }
    }

    return bigger;
  }

  // openModalWindow
  openModalWindow(modalId) {
    const modalRef = this.modalService.open(modalId);
    modalRef.result.then((result) => {
    }, (reason) => {
    });
    return modalRef;
  }
}
