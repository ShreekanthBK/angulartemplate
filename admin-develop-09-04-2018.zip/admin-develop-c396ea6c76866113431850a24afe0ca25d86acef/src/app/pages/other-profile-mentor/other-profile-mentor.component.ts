import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DataService } from '../../services/data.service';

@Component({
  selector: 'app-other-profile-mentor',
  templateUrl: './other-profile-mentor.component.html',
  styleUrls: ['./other-profile-mentor.component.scss']
})
export class OtherProfileMentorComponent implements OnInit, OnDestroy {
  errorMessage: string;
  dataList: any[] = [];

  reviewsData = [];
  showMessageBar = false;

  @ViewChild('newMeetingRequestModal') newMeetingRequestModal: any;
  @ViewChild('confirmRequestModal') confirmRequestModal: any;
  @ViewChild('connectSentModal') connectSentModal: any;
  newMeetingRequestModalRef: NgbModalRef;
  confirmRequestModalRef: NgbModalRef;
  connectSentModalRef: NgbModalRef;

  hiddenElementGroup = {
    showMenu: false,
    showSearchPopup: false,
    showSearchPopupMobile: false,
    showNotification: false
  };


  constructor(public dataService: DataService, private modalService: NgbModal) {}

  /**
   * OnInit
   */
  ngOnInit() {
    this.dataService.getData('dataOtherProfile').then((data: any) => this.dataList = data).then(() => {
      this.initData();
    });
  }

  initData() {
    this.reviewsData = this.dataList['formData'][0]['reviewsData'];
  }

  // connect Sent
  connectSent() {
    this.dataList['sentRequest'] = true;

    if (Math.floor(Math.random() * 2) === 1) {
      setTimeout( () => {
        this.dataList['status'] = 'Connected';
      }, 2000);
    } else {
      setTimeout( () => {
        this.dataList['status'] = 'Rejected';
      }, 2000);
    }
    this.showMessageBar = true;
  }

  /**
   * OnDestroy
   */
  ngOnDestroy() {
    if (this.newMeetingRequestModalRef !== undefined) {
      this.newMeetingRequestModalRef.close();
    }

    if (this.confirmRequestModalRef !== undefined) {
      this.confirmRequestModalRef.close();
    }

    if (this.connectSentModalRef !== undefined) {
      this.connectSentModalRef.close();
    }
  }

  // openModalWindow
  openModalWindow(modalId) {
    const modalRef = this.modalService.open(modalId);
    modalRef.result.then((result) => {
    }, (reason) => {
    });
    return modalRef;
  }

}
