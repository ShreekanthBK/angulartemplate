import { Component } from '@angular/core';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent {

  open = false;

  toggleMenu($event = true) {
    if ($event === false && this.open === false) {
      this.open = false;
    } else {
      this.open = !this.open;
    }
  }

}
