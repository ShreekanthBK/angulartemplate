import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {DataService} from '../../services/data.service';

@Component({
  selector: 'app-learning-area-config',
  templateUrl: './learning-area-config.component.html',
  styleUrls: ['./learning-area-config.component.scss']
})
export class LearningAreaConfigComponent implements OnInit {

  @ViewChild('feedbackTemplate') feedbackTemplate: ElementRef;
  @ViewChild('feedbackTemplate') remindersTemplate: ElementRef;
  confirmModalTitle = '';
  confirmModalMessage = '';
  confirmModalValue = null;
  confirmModalType = null;
  previewContent = null;
  showPreviewPopup = false;
  showInvitePopup = false;
  bulkUploadModal = false;
  previewTitle = '';
  rightTab = 'MENTORS';
  learning: any = {
    name: '',
    duration: '',
    mailsFrequency: '',
    feedbackFrequency: '',
    feedbackForms: '',
    feedbackFormsName: '',
    feedbackTemplate: '',
    remindersMail: '',
    remindersMailName: '',
    remindersTemplate: '',
    frequency: [],
    mentor: {},
    mentee: {},
    mentors: [],
    mentees: [],
    pending: [],
    users: [],
    menteeUsers: [],
  };
  learningError: any = {
    mailsFrequency: false,
    feedbackFrequency: false,
    duration: false,
    selectedFeedback: false
  };

  constructor(private dataService: DataService) {
  }

  ngOnInit() {
    this.dataService.getData('edit-learning-areas').then((data: any) => this.learning = data);
  }

  /**
   * Drop down on select event
   * @param event
   * @param field
   */
  onSelect(event, field) {
    this.learning[field] = event;
  }

  /**
   * Show preview
   * @param type - type [reminder/ feedback]
   * @param name - Selected template name
   */
  showPreview(type, name) {
    this.dataService.getData(type + '-template').then((data: any) => {
      this.previewContent = data.template;
      this.showPreviewPopup = true;
      this.previewTitle = name;
    });

  }

  /**
   * Close preview modal
   */
  closePreview() {
    this.showPreviewPopup = false;
    this.previewContent = null;
  }

  /**
   * show Invite modal
   */
  showInviteModal() {
    this.showInvitePopup = true;
  }

  /**
   * Close Invite modal
   */
  closeInviteModal() {
    this.showInvitePopup = false;
  }

  onSave() {
    this.showConfirmModal('SAVE', this.learning, 'Save', 'Are you sure you want to perform this action?');
  }

  /**
   * Open bulk upload modal
   */
  openBulkUpdateModal() {
    this.bulkUploadModal = true;
  }

  /**
   * Update bulk upload
   */
  updateBulkUpdateModal() {
    console.log('Updating');
  }

  /**
   * Close bulk upload modal
   */
  closeBulkUpdateModal() {
    this.bulkUploadModal = false;
  }

  /**
   * File selected
   * @param event - event
   * @param field - field name
   */
  fileChange(event, field) {
    const fileList: FileList = event.target.files;
    if (fileList.length > 0) {
      this.learning[field] = fileList[0];
    }
  }

  /**
   * Show File Dialog
   * @param field - field name
   */
  showBrowseDlg(field) {
    this[field].nativeElement.click();
  }

  /**
   * Confirmation modal Yes action
   * @param type - type of action
   * @param value - callback values
   * @param title - title
   * @param message - message
   */
  showConfirmModal(type, value, title, message) {
    this.confirmModalTitle = title;
    this.confirmModalMessage = message;
    this.confirmModalValue = value;
    this.confirmModalType = type;
  }

  /**
   * Confirmation modal Yes action
   * @param type - type of action
   */
  yesConfirmModal({type}) {
    if (type === 'SAVE') {
      this.hideConfirmModal();
    }
  }

  /**
   * Confirmation modal No action
   */
  hideConfirmModal() {
    this.confirmModalTitle = '';
    this.confirmModalMessage = '';
    this.confirmModalValue = null;
    this.confirmModalType = null;
  }

}
