import {Component, OnInit} from '@angular/core';
import {DataService} from '../../services/data.service';

@Component({
  selector: 'app-sub-admin',
  templateUrl: './sub-admin.component.html',
  styleUrls: ['./sub-admin.component.scss']
})
export class SubAdminComponent implements OnInit {

  confirmModalTitle = '';
  confirmModalMessage = '';
  confirmModalValue = null;
  confirmModalType = null;
  data = {
    member: {},
    admins: [],
    activity: [],
    businessLineDropDown: [],
    learningAreasDropDown: [],
    categoryDropDown: []
  };
  messageModalTitle = '';
  messageModalMessage = '';
  showAssignPopup = false;

  constructor(private dataService: DataService) {
  }

  ngOnInit() {
    this.dataService.getData('sub-admin').then((data: any) => this.data = data);
  }

  /**
   * Show assign modal
   */
  showAssignModal() {
    this.showAssignPopup = true;
  }

  /**
   * Hide assign modal
   */
  hideAssignModal() {
    this.showAssignPopup = false;
  }

  /**
   * Remove sub admins
   * @param index
   */
  removeSubAdmin(index) {
    this.showConfirmModal('REMOVE', index, 'REMOVE', 'Are you sure you want to perform this action?');
  }

  /**
   * Show Message modal
   * @param title - title of the message modal
   * @param message - message of the message modal
   */
  showMessageModal(title, message) {
    this.messageModalTitle = title;
    this.messageModalMessage = message;
  }

  /**
   * Close message modal
   */
  closeMessageModal() {
    this.messageModalTitle = '';
    this.messageModalMessage = '';
  }


  /**
   * Confirmation modal Yes action
   * @param type - type of action
   * @param value - callback values
   * @param title - title
   * @param message - message
   */
  showConfirmModal(type, value, title, message) {
    this.confirmModalTitle = title;
    this.confirmModalMessage = message;
    this.confirmModalValue = value;
    this.confirmModalType = type;
  }

  /**
   * Confirmation modal Yes action
   * @param type - type of action
   * @param value - type of action
   */
  yesConfirmModal({type, value}) {
    this.hideConfirmModal();
    if (type === 'REMOVE') {
      this.data.admins.splice(value, 1);
      this.showMessageModal('Remove Sub Admin', 'Sub Admin removed successfully.');
    }
  }

  /**
   * Confirmation modal No action
   */
  hideConfirmModal() {
    this.confirmModalTitle = '';
    this.confirmModalMessage = '';
    this.confirmModalValue = null;
    this.confirmModalType = null;
  }

}
