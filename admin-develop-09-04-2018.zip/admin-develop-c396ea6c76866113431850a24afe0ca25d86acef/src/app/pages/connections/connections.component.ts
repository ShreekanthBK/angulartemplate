import {Component, OnInit} from '@angular/core';
import {DataService} from '../../services/data.service';

@Component({
  selector: 'app-connections',
  templateUrl: './connections.component.html',
  styleUrls: ['./connections.component.scss']
})
export class ConnectionsComponent implements OnInit {

  confirmModalTitle = '';
  confirmModalMessage = '';
  confirmModalValue = null;
  confirmModalType = null;
  connectionLimitPopup = false;
  tab = 'ALL';
  MAX_LOADS: any = 2;
  NO_OF_LOAD: any = 0;
  category = 'PROGRAMMING';
  subCategory = 'ALL LEARNING AREAS';
  data: any = {
    connections: [],
    category: [],
    subCategory: {},
    mentor: {},
    mentee: {},
    menteeDropDown: {},
    mentorDropDown: {},
  };

  constructor(private dataService: DataService) {
  }

  ngOnInit() {
    this.dataService.getData('connection').then((data: any) => this.data = data);
  }

  /**
   * select dropdown
   * @param value - value
   * @param field - field name
   */
  onSelect(value, field) {
    this[field] = value;
    if (field === 'category') {
      this.subCategory = 'ALL LEARNING AREAS';
    }
  }

  /**
   * hide connection limit modal
   */
  closeConnectionLimitModal() {
    this.connectionLimitPopup = false;
  }

  /**
   * show connection limit modal
   */
  showConnectionLimitModal() {
    this.connectionLimitPopup = true;
  }

  /**
   * Load more data
   */
  loadMore() {
    this.dataService.getData('connection-more').then((data: any) => {
      this.NO_OF_LOAD += 1;
      this.data.connections = this.data.connections.concat(data.connections);
    });
  }

  /**
   * Close connection
   * @param index - index
   */
  onClose(index) {
    this.showConfirmModal('CLOSE', index, 'Close', 'Are you sure you want to perform this action?');
  }

  /**
   * Confirmation modal Yes action
   * @param type - type of action
   * @param value - callback values
   * @param title - title
   * @param message - message
   */
  showConfirmModal(type, value, title, message) {
    this.confirmModalTitle = title;
    this.confirmModalMessage = message;
    this.confirmModalValue = value;
    this.confirmModalType = type;
  }

  /**
   * Confirmation modal Yes action
   * @param type - type of action
   * @param value - type of action
   */
  yesConfirmModal({type, value}) {
    if (type === 'CLOSE') {
      this.data.connections[value].status = 'closed';
      this.data.connections[value].isNew = false;
      this.hideConfirmModal();
    }
  }

  /**
   * Confirmation modal No action
   */
  hideConfirmModal() {
    this.confirmModalTitle = '';
    this.confirmModalMessage = '';
    this.confirmModalValue = null;
    this.confirmModalType = null;
  }
}
