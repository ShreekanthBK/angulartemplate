import {Component, OnInit} from '@angular/core';
import {DataService} from '../../services/data.service';

@Component({
  selector: 'app-mentors',
  templateUrl: './mentors.component.html',
  styleUrls: ['./mentors.component.scss']
})
export class MentorsComponent implements OnInit {

  confirmModalTitle = '';
  confirmModalMessage = '';
  confirmModalValue = null;
  confirmModalType = null;
  tab = 'ACTIVE';
  messageModalTitle = '';
  messageModalMessage = '';
  mentorModal = {
    visibility: false,
    actionText: 'Add Mentor',
    title: 'Add new mentor',
    uploadText: 'Upload Mentors',
    dropText: 'Drag and drop mentor list here or ',
  };
  data = {
    topMentors: [],
    newRequests: [],
    mailInvitations: [],
    rejectedRequests: [],
    activeRequests: [],
    pageSizes: [],
    mentorsList: [],
    learningDropDown: [],
    categoryDropDown: [],
  };

  constructor(private dataService: DataService) {
  }

  ngOnInit() {
    this.dataService.getData('mentors').then((data: any) => this.data = data);
  }

  /**
   * Show Add new mentor modal
   */
  showAddMentor() {
    this.mentorModal = {
      visibility: true,
      actionText: 'Add Mentor',
      title: 'Add new mentor',
      uploadText: 'Upload Mentors',
      dropText: 'Drag and drop mentor list here or ',
    };
  }

  /**
   * Show Mail Employee to register modal
   */
  showMailEmployee() {
    this.mentorModal = {
      visibility: true,
      actionText: 'Mail Employee',
      title: 'Mail Employee to register',
      uploadText: 'Upload Employee',
      dropText: 'Drag and drop employee email list here or',
    };
  }

  /**
   * Hide modal
   */
  hideModal() {
    this.mentorModal.visibility = false;
  }

  /**
   * Complete modal
   */
  completeMessage() {
    this.mentorModal.visibility = false;
    this.showMessageModal(this.mentorModal.title, this.mentorModal.actionText + ' successful.');
  }

  /**
   * Show Message modal
   * @param title - title of the message modal
   * @param message - message of the message modal
   */
  showMessageModal(title, message) {
    this.messageModalTitle = title;
    this.messageModalMessage = message;
  }

  /**
   * Close message modal
   */
  closeMessageModal() {
    this.messageModalTitle = '';
    this.messageModalMessage = '';
  }

  onTableAction({type, value}) {
    this.showConfirmModal(type, value, type, 'Are you sure you want to perform this action?');
  }

  /**
   * Confirmation modal Yes action
   * @param type - type of action
   * @param value - callback values
   * @param title - title
   * @param message - message
   */
  showConfirmModal(type, value, title, message) {
    this.confirmModalTitle = title;
    this.confirmModalMessage = message;
    this.confirmModalValue = value;
    this.confirmModalType = type;
  }

  /**
   * Confirmation modal Yes action
   * @param type - type of action
   * @param value - type of action
   */
  yesConfirmModal({type, value}) {
    this.hideConfirmModal();
    if (type === 'REMOVE') {
      this.removeItem(value);
    }
  }

  /**
   * Confirmation modal No action
   */
  hideConfirmModal() {
    this.confirmModalTitle = '';
    this.confirmModalMessage = '';
    this.confirmModalValue = null;
    this.confirmModalType = null;
  }

  /**
   * Remove row item
   * @param index
   */
  removeItem(index) {
    let idx = 0;
    for (let i = 0; i < this.data.activeRequests.length; i++) {
      if (this.data.activeRequests[i].id === index) {
        idx = i;
      }
    }
    this.data.activeRequests.splice(idx, 1);
  }
}
