import { Component, OnInit } from '@angular/core';

import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import {DataService} from '../../services/data.service';

@Component({
  selector: 'app-mentor-profile-edit',
  templateUrl: './mentor-profile-edit.component.html',
  styleUrls: ['./mentor-profile-edit.component.scss']
})
export class MentorProfileEditComponent implements OnInit {
  errorMessage: string;
  dataList: any[] = [];

  reviewsData = [];

  modelPeriodFrom: NgbDateStruct;
  modelPeriodTo: NgbDateStruct;
  modelPeriodFromStored: NgbDateStruct;
  modelPeriodToStored: NgbDateStruct;

  hiddenElementGroup = {
    showMenu: false,
    showSearchPopup: false,
    showSearchPopupMobile: false,
    showNotification: false
  };

  constructor(private dataService: DataService) {}


  /**
   * OnInit
   */
  ngOnInit() {
    this.dataService.getData('dataMyProfileEdit').then((data: any) => this.dataList = data).then(() => {
      this.initData();
    });
    this.modelPeriodFromStored = { year: null, month: null, day: null };
    this.modelPeriodToStored = { year: null, month: null, day: null };
  }

  initData() {
    // set date value
    const strFrom = this.dataList['formData'][0]['workDetails'][0]['timeFrom'].split('-');
    const strTo = this.dataList['formData'][0]['workDetails'][0]['timeTo'].split('-');
    this.modelPeriodFrom = { year: parseInt(strFrom[0], 10), month: parseInt(strFrom[1], 10), day: parseInt(strFrom[2], 10) };
    this.modelPeriodTo = { year: parseInt(strTo[0], 10), month: parseInt(strTo[1], 10), day: parseInt(strTo[2], 10) };
  }

  onChangePic(event) {
    this.dataList['userPhoto'] = '../../../assets/i/mentor-pic1.png';
  }

  // empty Form
  emptyForm(dataList) {
    dataList['formData'] = [{
      'isMentor': false,
      'personalDetails': {
        'Name': '',
        'Email': '',
        'Phone': '',
        'Domain': '',
        'Designation': '',
        'Location': '',
        'Wipro Experience': '',
        'Total Experience': ''
      },
      'aboutMyCurrentRole': {
        'description': '',
        'specialties': '' ,
        'strengthAreas': ''
      },
      'workDetails': [
        {
          'img': '',
          'title': '',
          'timeFrom': '',
          'timeTo': '',
          'description': ''
        }
      ],
      'Volunteer as Mentee': {
        'description': '',
        'learningCategory': 'All',
        'learningArea': 'All',
        'keyStrengths': ''
      },
      'Volunteer as Mentor': {
        'description': 'Dummy',
        'learningCategory': 'All',
        'learningArea': 'All',
        'keyStrengths': 'Dummy'
      },
      'Skills and Band': {
        'list': [
          {
            'value': ''
          }
        ],
        'band': 'All'
      },
      'reviewsData': {
        'labelMin': '0',
        'labelMax': '0',
        'length': 0,
        'list': [
        ]
      }
    }];
  }


}
