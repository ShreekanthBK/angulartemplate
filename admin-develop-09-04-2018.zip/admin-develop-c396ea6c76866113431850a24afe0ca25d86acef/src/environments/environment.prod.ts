export const environment = {
  production: true,
  api: '/assets/data/{name}.json'
};
